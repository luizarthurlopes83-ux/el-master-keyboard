package com.elmaster.keyboard

import android.content.Context

/** Configurações em memória + persistência em SharedPreferences. */
object Prefs {
    var rainbow = true
    var hue = 280
    var opacity = 85        // 30..100 (%)
    var keySizeDp = 68      // tamanho das teclas
    var swipePx = 320       // distância do gesto
    var repeatMs = 110      // intervalo do pressionamento contínuo
    var posX = 40
    var posY = -1

    private const val N = "el_master"

    fun load(c: Context) {
        val s = c.getSharedPreferences(N, Context.MODE_PRIVATE)
        rainbow = s.getBoolean("rainbow", true)
        hue = s.getInt("hue", 280)
        opacity = s.getInt("opacity", 85)
        keySizeDp = s.getInt("keySizeDp", 68)
        swipePx = s.getInt("swipePx", 320)
        repeatMs = s.getInt("repeatMs", 110)
        posX = s.getInt("posX", 40)
        posY = s.getInt("posY", -1)
    }

    fun save(c: Context) {
        c.getSharedPreferences(N, Context.MODE_PRIVATE).edit()
            .putBoolean("rainbow", rainbow).putInt("hue", hue).putInt("opacity", opacity)
            .putInt("keySizeDp", keySizeDp).putInt("swipePx", swipePx).putInt("repeatMs", repeatMs)
            .putInt("posX", posX).putInt("posY", posY).apply()
    }
}
