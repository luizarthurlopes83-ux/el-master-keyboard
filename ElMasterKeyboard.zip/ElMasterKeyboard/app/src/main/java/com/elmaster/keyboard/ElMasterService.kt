package com.elmaster.keyboard

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Serviço de acessibilidade (autorizado pelo usuário):
 *  - cada tecla é uma janela flutuante independente (posição e tamanho livres);
 *  - cada toque vira um gesto de deslizar injetado com dispatchGesture().
 */
class ElMasterService : AccessibilityService() {

    companion object {
        @Volatile var instance: ElMasterService? = null
        private const val HOLD_DELAY_MS = 180L
        private const val MAX_HOLD_MS = 8000L
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val views = arrayOfNulls<RgbKeyView>(4)
    private val lps = arrayOfNulls<WindowManager.LayoutParams>(4)
    private val repeaters = HashMap<Int, Runnable>()
    private var panel: View? = null
    private var shown = false
    private var selected = 0
    private var busy = false
    private val clearBusy = Runnable { busy = false }

    // pontos candidatos para o gesto, do mais central ao mais afastado
    private val spots = listOf(0.5f, 0.3f, 0.7f, 0.15f, 0.85f).flatMap { fx ->
        listOf(0.40f, 0.30f, 0.50f, 0.20f, 0.60f, 0.70f, 0.12f).map { fy -> fx to fy }
    }.sortedBy { (it.first - 0.5f) * (it.first - 0.5f) + (it.second - 0.4f) * (it.second - 0.4f) }

    override fun onServiceConnected() {
        instance = this
        Prefs.load(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        hide(); instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        hide(); instance = null
        super.onDestroy()
    }

    fun isShown() = shown
    fun toggle() { if (shown) { Prefs.editMode = false; hide() } else show() }
    fun rebuild() { if (shown) { hide(); show() } }

    fun setEditMode(on: Boolean) {
        Prefs.editMode = on
        stopRepeaters()
        if (on) { show(); showPanel(); select(selected) } else { hidePanel(); Prefs.save(this) }
        views.forEach { it?.reset() }
    }

    // ---------- Janelas das teclas ----------
    private fun defaultPos(i: Int): Pair<Int, Int> {
        val m = resources.displayMetrics
        val u = (74 * m.density).toInt()
        val x0 = (30 * m.density).toInt()
        val y0 = (m.heightPixels * 0.58f).toInt()
        return when (i) {
            0 -> (x0 + u) to y0
            1 -> x0 to (y0 + u)
            2 -> (x0 + u) to (y0 + u)
            else -> (x0 + 2 * u) to (y0 + u)
        }
    }

    private fun show() {
        if (shown) return
        val d = resources.displayMetrics.density
        for (i in 0..3) {
            val k = (Prefs.size[i] * d).toInt()
            val lp = WindowManager.LayoutParams(
                k, k,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                val (dx, dy) = defaultPos(i)
                x = if (Prefs.px[i] != Prefs.NONE) Prefs.px[i] else dx
                y = if (Prefs.py[i] != Prefs.NONE) Prefs.py[i] else dy
            }
            val v = RgbKeyView(this, Prefs.label[i]).apply {
                onDown = { press(i) }
                onUp = { release(i) }
            }
            attachEdit(v, lp, i)
            wm.addView(v, lp)
            views[i] = v; lps[i] = lp
        }
        shown = true
        if (Prefs.editMode) showPanel()
    }

    private fun hide() {
        stopRepeaters()
        for (i in 0..3) {
            views[i]?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            views[i] = null; lps[i] = null
        }
        hidePanel()
        shown = false
    }

    // ---------- Modo editar ----------
    private fun attachEdit(v: RgbKeyView, lp: WindowManager.LayoutParams, i: Int) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        v.editTouch = { e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { select(i); sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> { Prefs.px[i] = lp.x; Prefs.py[i] = lp.y; Prefs.save(this) }
            }
            true
        }
    }

    private fun select(i: Int) {
        selected = i
        views.forEachIndexed { idx, vw -> vw?.picked = (idx == i); vw?.invalidate() }
    }

    private fun resizeSelected(delta: Int) {
        val i = selected
        val v = views[i] ?: return
        val lp = lps[i] ?: return
        Prefs.size[i] = (Prefs.size[i] + delta).coerceIn(40, 150)
        val k = (Prefs.size[i] * resources.displayMetrics.density).toInt()
        lp.width = k; lp.height = k
        wm.updateViewLayout(v, lp); Prefs.save(this)
    }

    private fun resetSelected() {
        val i = selected
        val v = views[i] ?: return
        val lp = lps[i] ?: return
        Prefs.size[i] = Prefs.DEF_SIZE; Prefs.px[i] = Prefs.NONE; Prefs.py[i] = Prefs.NONE
        val k = (Prefs.DEF_SIZE * resources.displayMetrics.density).toInt()
        val (dx, dy) = defaultPos(i)
        lp.width = k; lp.height = k; lp.x = dx; lp.y = dy
        wm.updateViewLayout(v, lp); Prefs.save(this)
    }

    private fun showPanel() {
        if (panel != null) return
        val d = resources.displayMetrics.density
        val p = (10 * d).toInt()
        fun btn(t: String, onClick: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER
            setPadding(p * 2, p, p * 2, p)
            setOnClickListener { onClick() }
        }
        val hint = TextView(this).apply {
            text = "Toque numa tecla e arraste • − / + muda o tamanho"
            setTextColor(Color.LTGRAY); textSize = 11f; gravity = Gravity.CENTER
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            addView(btn("−") { resizeSelected(-6) })
            addView(btn("+") { resizeSelected(6) })
            addView(btn("↺") { resetSelected() })
            addView(btn("✔ Pronto") { setEditMode(false) })
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(p, p, p, p)
            background = GradientDrawable().apply {
                setColor(Color.argb(225, 10, 10, 20)); cornerRadius = 20 * d
                setStroke((2 * d).toInt(), Color.parseColor("#00E5FF"))
            }
            addView(hint); addView(buttons)
        }
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = (70 * d).toInt() }
        wm.addView(box, lp)
        panel = box
    }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    // ---------- Entrada ----------
    private fun stopRepeaters() {
        repeaters.values.forEach { handler.removeCallbacks(it) }
        repeaters.clear()
    }

    private fun press(i: Int) {
        release(i)
        fire(Prefs.action[i], true)
        val t0 = SystemClock.uptimeMillis()
        val r = object : Runnable {
            override fun run() {
                val v = views[i]
                if (v == null || !v.isHeld || SystemClock.uptimeMillis() - t0 > MAX_HOLD_MS) {
                    repeaters.remove(i); return
                }
                fire(Prefs.action[i], false)
                handler.postDelayed(this, Prefs.repeatMs.toLong())
            }
        }
        repeaters[i] = r
        handler.postDelayed(r, HOLD_DELAY_MS)
    }

    private fun release(i: Int) { repeaters.remove(i)?.let { handler.removeCallbacks(it) } }

    /** a: 0=cima 1=baixo 2=esquerda 3=direita */
    private fun fire(a: Int, force: Boolean) {
        if (busy && !force) return
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val sh = m.heightPixels.toFloat()
        val h = Prefs.swipePx / 2f
        val (dx, dy) = when (a) {
            0 -> 0f to -h
            1 -> 0f to h
            2 -> -h to 0f
            else -> h to 0f
        }
        // ponto do gesto que NÃO cruza nenhuma tecla (evita o gesto "apertar" o próprio teclado)
        val boxes = ArrayList<RectF>()
        val loc = IntArray(2)
        for (vw in views) {
            if (vw == null) continue
            vw.getLocationOnScreen(loc)
            boxes.add(RectF(loc[0].toFloat(), loc[1].toFloat(), (loc[0] + vw.width).toFloat(), (loc[1] + vw.height).toFloat()))
        }
        var cx = -1f
        var cy = -1f
        val ax = abs(dx) + 40f
        val ay = abs(dy) + 40f
        for ((fx, fy) in spots) {
            val x = w * fx
            val y = sh * fy
            if (x - ax < 0 || x + ax > w || y - ay < 0 || y + ay > sh) continue
            val area = RectF(x - ax, y - ay, x + ax, y + ay)
            if (boxes.none { RectF.intersects(it, area) }) { cx = x; cy = y; break }
        }
        if (cx < 0) return
        busy = true
        handler.removeCallbacks(clearBusy)
        handler.postDelayed(clearBusy, 250)
        val path = Path().apply { moveTo(cx - dx, cy - dy); lineTo(cx + dx, cy + dy) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 45))
            .build()
        dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { busy = false }
            override fun onCancelled(gestureDescription: GestureDescription?) { busy = false }
        }, null)
    }
}
