# EL MASTER KEYBOARD

Teclado gamer virtual flutuante (RGB) para jogar Subway Surfers no Chrome.

## Como usar (3 passos)
1. Abra o app e toque em **1 · ATIVAR** → ative "EL MASTER KEYBOARD" em Acessibilidade.
2. Volte ao app e toque em **MOSTRAR TECLADO**.
3. Abra o Chrome e jogue.

## Recursos
- Cada tecla é independente: **✥ EDITAR LAYOUT** deixa arrastar cada tecla e mudar o tamanho (− / +) em qualquer posição.
- **⚙ PERSONALIZAR**: presets WASD / setas / IJKL / ESDF, editar letra e ação de cada tecla, cores RGB, brilho, tamanho geral, distância do swipe e repetição.
- Segurar a tecla repete a ação.

## Como funciona
O Android não permite a um app comum enviar teclas reais a outro app. O app usa o **Serviço de Acessibilidade** (autorizado por você) para desenhar as teclas sobre outros apps e injetar gestos de deslizar (cima/baixo/esquerda/direita). As letras são só o desenho da tecla. Nenhum dado é coletado.

## Gerar o APK
Android Studio: abra a pasta, aguarde o Gradle Sync e use **Build ▸ Build APK(s)**.
Linha de comando: `gradle wrapper --gradle-version 8.7` e depois `./gradlew assembleDebug`.
APK em `app/build/outputs/apk/debug/app-debug.apk`.
