# EL MASTER KEYBOARD

Teclado gamer virtual (WASD, borda RGB animada) que flutua sobre o Google Chrome para jogar Subway Surfers.

| Tecla | Ação        | Gesto injetado |
|-------|-------------|----------------|
| W     | Pular       | deslizar ↑     |
| A     | Esquerda    | deslizar ←     |
| S     | Deslizar    | deslizar ↓     |
| D     | Direita     | deslizar →     |

Segurar a tecla repete a ação (intervalo ajustável).

## Como funciona (e por que assim)
O Android **não permite** que um app comum injete eventos de teclado em outro app (isso exige permissão de sistema/root).
O mecanismo oficial e autorizado pelo usuário é o **Serviço de Acessibilidade**, que:
- desenha o painel sobre outros apps (`TYPE_ACCESSIBILITY_OVERLAY`, sem pedir "sobrepor a outros apps");
- envia gestos de toque ao Chrome via `dispatchGesture()`.
A versão mobile do Subway Surfers no Chrome é controlada por deslizes, então WASD é mapeado para eles.
O app não lê tela nem coleta dados.

## Gerar o APK (Android Studio — mais fácil)
1. Instale o Android Studio (Koala ou mais novo) e abra a pasta `ElMasterKeyboard`.
2. Aguarde o *Gradle Sync* (baixa tudo sozinho; precisa de internet).
3. Menu **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**.
4. O arquivo fica em `app/build/outputs/apk/debug/app-debug.apk`.

## Gerar pela linha de comando
Com JDK 17 e Android SDK (variável `ANDROID_HOME`) instalados:
```
gradle wrapper --gradle-version 8.7     # uma vez, cria o ./gradlew
./gradlew assembleDebug                 # Windows: gradlew.bat assembleDebug
```
APK em `app/build/outputs/apk/debug/app-debug.apk` (já assinado com chave de debug, instalável).

## Instalar e usar
1. Copie o APK ao celular e instale (permita "instalar apps desconhecidos").
2. Abra **EL MASTER KEYBOARD** ▸ **1. Ativar serviço de acessibilidade** ▸ ative o serviço.
   - Android 13+: se o botão estiver cinza, vá em *Configurações ▸ Apps ▸ EL MASTER KEYBOARD ▸ ⋮ ▸ Permitir configurações restritas* e tente de novo.
3. O teclado aparece sobre qualquer app. Abra o Chrome com o Subway Surfers e jogue.
4. Arraste pela barra "⠿ EL MASTER"; 🎨 troca as cores; ✕ oculta (reabra pelo botão 2 do app).
5. Ajuste cor, brilho, tamanho, distância do swipe e velocidade de repetição na tela principal.

## Observações
- Os gestos são feitos no centro da tela; se o teclado estiver por cima, o app escolhe sozinho outro ponto livre.
- Se o jogo não reconhecer o swipe, aumente "Distância do swipe".
- Para eventos de teclado reais (Chrome em modo desktop), seria preciso Shizuku/ADB (`input keyevent`) ou um teclado Bluetooth HID — fora do escopo de um app comum.
