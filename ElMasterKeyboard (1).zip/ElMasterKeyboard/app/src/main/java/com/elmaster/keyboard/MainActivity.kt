package com.elmaster.keyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.load(this)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }

        fun tv(s: String, size: Float, color: Int) = TextView(this).apply {
            text = s; textSize = size; setTextColor(color); setPadding(0, (10 * d).toInt(), 0, 0)
        }

        col.addView(tv("EL MASTER KEYBOARD", 24f, Color.parseColor("#00E5FF")).apply { typeface = Typeface.DEFAULT_BOLD })
        status = tv("", 14f, Color.LTGRAY); col.addView(status)

        fun button(s: String, onClick: () -> Unit) {
            col.addView(Button(this).apply { text = s; setOnClickListener { onClick() } })
        }
        button("1. Ativar serviço de acessibilidade") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("2. Mostrar / ocultar teclado") {
            val s = ElMasterService.instance
            if (s == null) Toast.makeText(this, "Ative o serviço primeiro (passo 1)", Toast.LENGTH_LONG).show()
            else s.toggle()
        }

        col.addView(Switch(this).apply {
            text = "Modo mover (arraste as teclas)"; setTextColor(Color.WHITE); isChecked = Prefs.moveMode
            setOnCheckedChangeListener { _, on -> Prefs.moveMode = on }
        })

        val sw = Switch(this).apply {
            text = "RGB arco-íris"; setTextColor(Color.WHITE); isChecked = Prefs.rainbow
            setOnCheckedChangeListener { _, on -> Prefs.rainbow = on; Prefs.save(this@MainActivity) }
        }
        col.addView(sw)

        val mv = Switch(this).apply {
            text = "Modo mover (mostra a barra ⠿ 🎨 ✕)"; setTextColor(Color.WHITE); isChecked = Prefs.showBar
            setOnCheckedChangeListener { _, on ->
                Prefs.showBar = on; Prefs.save(this@MainActivity)
                ElMasterService.instance?.rebuild()
            }
        }
        col.addView(mv)

        fun seek(label: String, lo: Int, hi: Int, get: () -> Int, set: (Int) -> Unit, rebuild: Boolean = false) {
            val t = tv("$label: ${get()}", 14f, Color.WHITE)
            col.addView(t)
            col.addView(SeekBar(this).apply {
                max = hi - lo; progress = get() - lo
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                        set(v + lo); t.text = "$label: ${v + lo}"
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {
                        Prefs.save(this@MainActivity)
                        if (rebuild) ElMasterService.instance?.rebuild()
                    }
                })
            })
        }
        seek("Cor (matiz)", 0, 360, { Prefs.hue }, { Prefs.hue = it; if (Prefs.rainbow) sw.isChecked = false })
        seek("Brilho / opacidade (%)", 30, 100, { Prefs.opacity }, { Prefs.opacity = it })
        seek("Tamanho das teclas (dp)", 36, 110, { Prefs.keySizeDp }, { Prefs.keySizeDp = it }, true)
        seek("Distância do swipe (px)", 150, 600, { Prefs.swipePx }, { Prefs.swipePx = it })
        seek("Repetição ao segurar (ms)", 60, 300, { Prefs.repeatMs }, { Prefs.repeatMs = it })

        col.addView(tv(
            "Dica: ligue o \"Modo mover\", arraste as teclas para onde quiser e desligue para jogar. " +
                "Tamanho e cores ficam nos controles acima.", 13f, Color.GRAY))

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        val on = ElMasterService.instance != null
        status.text = if (on) "● Serviço ATIVO" else "○ Serviço desativado"
        status.setTextColor(if (on) Color.parseColor("#7CFF4D") else Color.parseColor("#FF5A5A"))
    }
}
