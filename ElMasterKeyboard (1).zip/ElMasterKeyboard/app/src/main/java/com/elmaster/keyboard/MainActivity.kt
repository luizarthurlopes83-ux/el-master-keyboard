package com.elmaster.keyboard

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var chip: TextView
    private lateinit var main: RgbKeyView
    private lateinit var editBtn: TextView
    private var keyBtns: List<TextView> = emptyList()
    private var anim: ValueAnimator? = null
    private val arrows = arrayOf("↑", "↓", "←", "→")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun pill(s: String, onClick: () -> Unit) = TextView(this).apply {
        text = s; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(8), dp(14), dp(8), dp(14))
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#14141F")); cornerRadius = dp(14).toFloat()
            setStroke(dp(2), Color.parseColor("#2A2A44"))
        }
        setOnClickListener { onClick() }
    }

    private fun row(vararg items: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        for (v in items) {
            addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(4), dp(4), dp(4), dp(4))
            })
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.load(this)
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(32), dp(20), dp(32))
        }

        // ----- Título RGB animado -----
        val title = tv("EL MASTER\nKEYBOARD", 36f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        val grad = LinearGradient(
            0f, 0f, dp(300).toFloat(), 0f,
            intArrayOf(0xFF00E5FF.toInt(), 0xFFFF2BD6.toInt(), 0xFFFFD400.toInt(), 0xFF7CFF4D.toInt(), 0xFF00E5FF.toInt()),
            null, Shader.TileMode.REPEAT
        )
        title.paint.shader = grad
        val mx = Matrix()
        anim = ValueAnimator.ofFloat(0f, dp(300).toFloat()).apply {
            duration = 2500; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { mx.setTranslate(it.animatedValue as Float, 0f); grad.setLocalMatrix(mx); title.invalidate() }
            start()
        }
        col.addView(title, LinearLayout.LayoutParams(match, wrap))
        col.addView(tv("Teclado gamer para jogar no Chrome", 14f, Color.GRAY).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(match, wrap))

        chip = tv("", 14f, Color.LTGRAY, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(14), 0, 0) }
        col.addView(chip, LinearLayout.LayoutParams(match, wrap))

        // ----- Botão principal -----
        main = RgbKeyView(this, "").apply {
            textScale = 0.26f
            onUp = { onMainClick() }
        }
        col.addView(main, LinearLayout.LayoutParams(match, dp(80)).apply { setMargins(0, dp(14), 0, dp(10)) })

        col.addView(tv("1  Ative o serviço\n2  Mostre o teclado\n3  Abra o Chrome e jogue", 14f, Color.LTGRAY).apply {
            setLineSpacing(0f, 1.3f)
        })

        // ----- Ações secundárias -----
        val cfg = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        editBtn = pill("✥  EDITAR LAYOUT") { onEditClick() }
        val cfgBtn = pill("⚙  PERSONALIZAR") {
            cfg.visibility = if (cfg.visibility == View.GONE) View.VISIBLE else View.GONE
        }
        col.addView(row(editBtn, cfgBtn), LinearLayout.LayoutParams(match, wrap).apply { setMargins(0, dp(18), 0, 0) })

        // ----- Personalizar -----
        cfg.addView(tv("TECLAS", 12f, Color.parseColor("#00E5FF"), true).apply { setPadding(dp(4), dp(12), 0, 0) })
        cfg.addView(row(
            pill("WASD") { setLabels("W", "A", "S", "D") },
            pill("↑ ← ↓ →") { setLabels("↑", "←", "↓", "→") },
            pill("IJKL") { setLabels("I", "J", "K", "L") },
            pill("ESDF") { setLabels("E", "S", "D", "F") }
        ))
        cfg.addView(tv("Toque numa tecla para trocar a letra e a ação:", 12f, Color.GRAY).apply { setPadding(dp(4), dp(6), 0, 0) })
        keyBtns = (0..3).map { i -> pill(keyText(i)) { editKey(i) } }
        cfg.addView(row(*keyBtns.toTypedArray()))

        cfg.addView(tv("VISUAL E CONTROLE", 12f, Color.parseColor("#00E5FF"), true).apply { setPadding(dp(4), dp(16), 0, 0) })
        val sw = Switch(this).apply {
            text = "RGB arco-íris"; setTextColor(Color.WHITE); isChecked = Prefs.rainbow
            setPadding(dp(4), dp(8), dp(4), dp(8))
            setOnCheckedChangeListener { _, on -> Prefs.rainbow = on; Prefs.save(this@MainActivity) }
        }
        cfg.addView(sw)

        fun seek(label: String, lo: Int, hi: Int, get: () -> Int, set: (Int) -> Unit, rebuild: Boolean = false) {
            val t = tv("$label: ${get()}", 13f, Color.WHITE).apply { setPadding(dp(4), dp(8), 0, 0) }
            cfg.addView(t)
            cfg.addView(SeekBar(this).apply {
                max = hi - lo; progress = get() - lo
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                        set(v + lo); t.text = "$label: ${v + lo}"
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {
                        Prefs.save(this@MainActivity)
                        if (rebuild) ElMasterService.instance?.rebuild()
                    }
                })
            })
        }
        seek("Cor (matiz)", 0, 360, { Prefs.hue }, { Prefs.hue = it; if (Prefs.rainbow) sw.isChecked = false })
        seek("Brilho (%)", 30, 100, { Prefs.opacity }, { Prefs.opacity = it })
        seek("Tamanho de todas as teclas", 48, 120, { Prefs.size[0] }, { for (i in 0..3) Prefs.size[i] = it }, true)
        seek("Distância do swipe (px)", 150, 600, { Prefs.swipePx }, { Prefs.swipePx = it })
        seek("Repetição ao segurar (ms)", 60, 300, { Prefs.repeatMs }, { Prefs.repeatMs = it })

        cfg.addView(pill("↺  RESETAR LAYOUT") {
            for (i in 0..3) { Prefs.size[i] = Prefs.DEF_SIZE; Prefs.px[i] = Prefs.NONE; Prefs.py[i] = Prefs.NONE }
            Prefs.save(this); ElMasterService.instance?.rebuild()
            Toast.makeText(this, "Layout resetado", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(match, wrap).apply { setMargins(dp(4), dp(18), dp(4), 0) })
        cfg.addView(tv("As letras são só o desenho da tecla: a ação é sempre um deslize (cima, baixo, esquerda ou direita).",
            12f, Color.GRAY).apply { setPadding(dp(4), dp(10), 0, 0) })

        col.addView(cfg, LinearLayout.LayoutParams(match, wrap))
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun keyText(i: Int) = "${Prefs.label[i]} ${arrows[Prefs.action[i]]}"

    private fun refreshKeyBtns() { keyBtns.forEachIndexed { i, b -> b.text = keyText(i) } }

    private fun setLabels(vararg l: String) {
        for (i in 0..3) Prefs.label[i] = l[i]
        Prefs.save(this); refreshKeyBtns(); ElMasterService.instance?.rebuild()
    }

    private fun onMainClick() {
        val s = ElMasterService.instance
        if (s == null) {
            Toast.makeText(this, "Ative \"EL MASTER KEYBOARD\" na lista", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } else {
            s.toggle(); refresh()
        }
    }

    private fun onEditClick() {
        val s = ElMasterService.instance
        if (s == null) {
            Toast.makeText(this, "Ative o serviço primeiro", Toast.LENGTH_LONG).show()
        } else {
            s.setEditMode(!Prefs.editMode); refresh()
        }
    }

    private fun editKey(i: Int) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0)
        }
        val et = EditText(this).apply {
            setText(Prefs.label[i]); hint = "Letra ou símbolo"
            filters = arrayOf(InputFilter.LengthFilter(2))
        }
        box.addView(et)
        val names = arrayOf("↑  Pular (deslizar para cima)", "↓  Deslizar (para baixo)", "←  Esquerda", "→  Direita")
        val rg = RadioGroup(this)
        names.forEachIndexed { idx, n -> rg.addView(RadioButton(this).apply { text = n; id = 1000 + idx }) }
        rg.check(1000 + Prefs.action[i])
        box.addView(rg)
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Editar tecla")
            .setView(box)
            .setPositiveButton("Salvar") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) Prefs.label[i] = t
                Prefs.action[i] = (rg.checkedRadioButtonId - 1000).coerceIn(0, 3)
                Prefs.save(this); refreshKeyBtns(); ElMasterService.instance?.rebuild()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun refresh() {
        val s = ElMasterService.instance
        val on = s != null
        chip.text = if (on) "●  SERVIÇO ATIVO" else "○  SERVIÇO DESATIVADO"
        chip.setTextColor(if (on) Color.parseColor("#7CFF4D") else Color.parseColor("#FF5A5A"))
        main.label = when {
            !on -> "1 · ATIVAR"
            s!!.isShown() -> "OCULTAR TECLADO"
            else -> "MOSTRAR TECLADO"
        }
        main.invalidate()
        editBtn.text = if (Prefs.editMode) "✔  TERMINAR EDIÇÃO" else "✥  EDITAR LAYOUT"
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onDestroy() { anim?.cancel(); super.onDestroy() }
}
