package com.elmaster.keyboard

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Serviço de acessibilidade (autorizado pelo usuário) que:
 *  1) desenha o teclado WASD sobre outros apps (TYPE_ACCESSIBILITY_OVERLAY);
 *  2) converte cada tecla em um gesto de deslizar injetado via dispatchGesture().
 * W = deslizar p/ cima (pular) | S = p/ baixo (rolar) | A = esquerda | D = direita
 */
class ElMasterService : AccessibilityService() {

    companion object {
        @Volatile var instance: ElMasterService? = null
        private const val HOLD_DELAY_MS = 180L
        private val PRESETS = intArrayOf(-1, 0, 30, 120, 190, 280, 320) // -1 = arco-íris
    }

    private lateinit var wm: WindowManager
    private var root: View? = null
    private val handler = Handler(Looper.getMainLooper())
    private val repeaters = HashMap<Char, Runnable>()

    override fun onServiceConnected() {
        instance = this
        Prefs.load(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        hideOverlay(); instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        hideOverlay(); instance = null
        super.onDestroy()
    }

    fun toggle() { if (root == null) showOverlay() else hideOverlay() }
    fun rebuild() { if (root != null) { hideOverlay(); showOverlay() } }

    // ---------- Overlay ----------
    private fun showOverlay() {
        if (root != null) return
        val d = resources.displayMetrics.density
        val k = (Prefs.keySizeDp * d).toInt()
        val g = (3 * d).toInt()
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val lp = WindowManager.LayoutParams(
            wrap, wrap,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.posX
            y = if (Prefs.posY >= 0) Prefs.posY else (resources.displayMetrics.heightPixels * 0.62f).toInt()
        }

        val col = object : LinearLayout(this@ElMasterService) {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = Prefs.moveMode
            override fun onTouchEvent(e: MotionEvent): Boolean {
                if (!Prefs.moveMode) return super.onTouchEvent(e)
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt()
                        wm.updateViewLayout(this, lp)
                    }
                    MotionEvent.ACTION_UP -> { Prefs.posX = lp.x; Prefs.posY = lp.y; Prefs.save(this@ElMasterService) }
                }
                return true
            }
        }.apply {
            orientation = LinearLayout.VERTICAL
            setPadding(g, g, g, g)
        }

        fun key(l: String) = RgbKeyView(this, l).apply {
            layoutParams = LinearLayout.LayoutParams(k, k).apply { setMargins(g, g, g, g) }
            onDown = { press(l[0]) }
            onUp = { release(l[0]) }
        }
        val row1 = LinearLayout(this).apply { gravity = Gravity.CENTER_HORIZONTAL; addView(key("W")) }
        val row2 = LinearLayout(this).apply { addView(key("A")); addView(key("S")); addView(key("D")) }

        col.addView(row1, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, wrap))
        col.addView(row2)

        wm.addView(col, lp)
        root = col
    }

    private fun hideOverlay() {
        repeaters.values.forEach { handler.removeCallbacks(it) }
        repeaters.clear()
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
    }

    private fun cyclePalette() {
        val cur = if (Prefs.rainbow) 0 else PRESETS.indexOf(Prefs.hue).coerceAtLeast(0)
        val n = PRESETS[(cur + 1) % PRESETS.size]
        if (n == -1) Prefs.rainbow = true else { Prefs.rainbow = false; Prefs.hue = n }
        Prefs.save(this)
    }

    // ---------- Entrada ----------
    private fun press(c: Char) {
        swipe(c)
        release(c)
        val r = object : Runnable {
            override fun run() { swipe(c); handler.postDelayed(this, Prefs.repeatMs.toLong()) }
        }
        repeaters[c] = r
        handler.postDelayed(r, HOLD_DELAY_MS)   // pressionamento contínuo
    }

    private fun release(c: Char) { repeaters.remove(c)?.let { handler.removeCallbacks(it) } }

    private fun swipe(c: Char) {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val sh = m.heightPixels.toFloat()
        val h = Prefs.swipePx / 2f
        val (dx, dy) = when (c) {
            'W' -> 0f to -h
            'S' -> 0f to h
            'A' -> -h to 0f
            else -> h to 0f
        }
        // Escolhe um ponto de gesto que NÃO cruze o próprio teclado
        var cx = w * 0.5f
        var cy = sh * 0.40f
        val r = root
        if (r != null) {
            val loc = IntArray(2)
            r.getLocationOnScreen(loc)
            val box = RectF(loc[0].toFloat(), loc[1].toFloat(),
                (loc[0] + r.width).toFloat(), (loc[1] + r.height).toFloat())
            val spots = listOf(0.5f to 0.40f, 0.5f to 0.25f, 0.5f to 0.55f,
                0.3f to 0.35f, 0.7f to 0.35f, 0.5f to 0.15f, 0.5f to 0.70f)
            for ((fx, fy) in spots) {
                val x = w * fx; val y = sh * fy
                val pad = 30f
                val area = RectF(x - abs(dx) - pad, y - abs(dy) - pad, x + abs(dx) + pad, y + abs(dy) + pad)
                if (!RectF.intersects(box, area)) { cx = x; cy = y; break }
            }
        }
        val path = Path().apply { moveTo(cx - dx, cy - dy); lineTo(cx + dx, cy + dy) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 45))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
