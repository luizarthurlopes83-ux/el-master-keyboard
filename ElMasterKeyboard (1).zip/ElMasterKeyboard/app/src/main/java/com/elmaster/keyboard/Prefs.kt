package com.elmaster.keyboard

import android.content.Context

/** Configurações em memória + persistência. Índices das teclas: 0,1,2,3 = W,A,S,D (posição padrão). */
object Prefs {
    const val NONE = Int.MIN_VALUE
    const val DEF_SIZE = 68

    var rainbow = true
    var hue = 280
    var opacity = 85
    var swipePx = 320
    var repeatMs = 110
    var editMode = false            // não persiste

    val label = arrayOf("W", "A", "S", "D")
    val action = intArrayOf(0, 2, 1, 3)          // 0=cima 1=baixo 2=esquerda 3=direita
    val size = intArrayOf(DEF_SIZE, DEF_SIZE, DEF_SIZE, DEF_SIZE)
    val px = intArrayOf(NONE, NONE, NONE, NONE)
    val py = intArrayOf(NONE, NONE, NONE, NONE)

    private const val N = "el_master2"

    fun load(c: Context) {
        val s = c.getSharedPreferences(N, Context.MODE_PRIVATE)
        rainbow = s.getBoolean("rainbow", true)
        hue = s.getInt("hue", 280)
        opacity = s.getInt("opacity", 85)
        swipePx = s.getInt("swipePx", 320)
        repeatMs = s.getInt("repeatMs", 110)
        for (i in 0..3) {
            label[i] = s.getString("l$i", label[i]) ?: label[i]
            action[i] = s.getInt("a$i", action[i])
            size[i] = s.getInt("s$i", DEF_SIZE)
            px[i] = s.getInt("x$i", NONE)
            py[i] = s.getInt("y$i", NONE)
        }
    }

    fun save(c: Context) {
        val e = c.getSharedPreferences(N, Context.MODE_PRIVATE).edit()
        e.putBoolean("rainbow", rainbow).putInt("hue", hue).putInt("opacity", opacity)
            .putInt("swipePx", swipePx).putInt("repeatMs", repeatMs)
        for (i in 0..3) {
            e.putString("l$i", label[i]).putInt("a$i", action[i]).putInt("s$i", size[i])
                .putInt("x$i", px[i]).putInt("y$i", py[i])
        }
        e.apply()
    }
}
