package com.elmaster.keyboard

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.sin

/** Tecla/botão gamer com borda RGB animada. */
class RgbKeyView(ctx: Context, var label: String) : View(ctx) {
    var onDown: (() -> Unit)? = null
    var onUp: (() -> Unit)? = null
    var editTouch: ((MotionEvent) -> Boolean)? = null
    var selected = false
    var textScale = 0.42f
    val isHeld: Boolean get() = held

    private var held = false
    private var phase = 0f
    private var anim: ValueAnimator? = null
    private val d = ctx.resources.displayMetrics.density
    private val rect = RectF()
    private val m = Matrix()
    private val hsv = floatArrayOf(0f, 1f, 1f)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 8 * d }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3 * d }
    private val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2 * d; color = Color.WHITE
        pathEffect = DashPathEffect(floatArrayOf(8 * d, 6 * d), 0f)
    }
    private val selP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4 * d; color = Color.WHITE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }

    fun reset() { held = false; invalidate() }

    private fun rgb(offset: Float): Int {
        hsv[0] = if (Prefs.rainbow) (phase + offset) % 360f
        else (Prefs.hue + 35f * sin(Math.toRadians((phase + offset).toDouble())).toFloat() + 360f) % 360f
        return Color.HSVToColor(hsv)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 3500; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { phase = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel(); anim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val r = 12 * d
        rect.set(4 * d, 4 * d, w - 4 * d, h - 4 * d)
        val a = Prefs.opacity * 255 / 100
        val c0 = rgb(0f); val c1 = rgb(120f); val c2 = rgb(240f)
        val sh = SweepGradient(w / 2, h / 2, intArrayOf(c0, c1, c2, c0), null)
        m.setRotate(phase, w / 2, h / 2); sh.setLocalMatrix(m)
        glow.shader = sh; glow.alpha = (a * 0.35f).toInt()
        line.shader = sh; line.alpha = a
        fill.color = if (held) (c0 and 0x00FFFFFF) or (a shl 24)
        else Color.argb((a * 0.55f).toInt(), 12, 12, 24)
        c.drawRoundRect(rect, r, r, fill)
        c.drawRoundRect(rect, r, r, glow)
        c.drawRoundRect(rect, r, r, line)
        if (Prefs.editMode && editTouch != null) c.drawRoundRect(rect, r, r, if (selected) selP else dash)
        txt.textSize = h * textScale
        val tw = txt.measureText(label)
        if (tw > w * 0.8f) txt.textSize = txt.textSize * (w * 0.8f / tw)
        txt.color = if (held) Color.BLACK else Color.WHITE
        c.drawText(label, w / 2, h / 2 - (txt.descent() + txt.ascent()) / 2, txt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (Prefs.editMode && editTouch != null) return editTouch?.invoke(e) ?: true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                held = true; invalidate()
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                onDown?.invoke()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (held) {
                held = false; invalidate(); onUp?.invoke()
            }
        }
        return true
    }
}
